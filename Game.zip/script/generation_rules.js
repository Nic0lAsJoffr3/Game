go = 0;
rules = [
      {c: 20,funs: [
      { n: "serra", v: 10, p: 0, h: 0 },
      { n: "serra", v: 10, p: 1, h: 0 },
      { n: "serra", v: 11, p: 0, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 12, p: 0, h: 0 },
      { n: "serra", v: 12, p: 1, h: 0 }
      ]},
      {c: 20,funs: [
      { n: "serra", v: 10, p: 0, h: 0 },
      { n: "serra", v: 16, p: 0, h: 0 },
      { n: "serra", v: 23, p: 0, h: 0 },
      { n: "serra", v: 10, p: 1, h: 0 },
      { n: "serra", v: 16, p: 1, h: 0 },
      { n: "serra", v: 23, p: 1, h: 0 }
      ]},
      {c: 15,funs: [
      { n: "serra", v: 11, p: 0, h: 0 },
      { n: "serra", v: 11, p: 0, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 11, p: 0, h: 0 },
      { n: "serra", v: 11, p: 0, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 }
      ]},
      {c: 15,funs: [
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 11, p: 0, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 11, p: 0, h: 0 }
      ]},
      {c: 30,funs: [
      { n: "serra", v: 05, p: 0, h: 0 },
      { n: "serra", v: 30, p: 0, h: 0 },
      { n: "serra", v: 40, p: 0, h: 0 },
      { n: "serra", v: 50, p: 0, h: 0 },
      { n: "serra", v: 40, p: 0, h: 0 },
      { n: "serra", v: 30, p: 0, h: 0 }
      ]},
      {c: 30,funs: [
      { n: "serra", v: 05, p: 1, h: 0 },
      { n: "serra", v: 30, p: 1, h: 0 },
      { n: "serra", v: 40, p: 1, h: 0 },
      { n: "serra", v: 50, p: 1, h: 0 },
      { n: "serra", v: 40, p: 1, h: 0 },
      { n: "serra", v: 30, p: 1, h: 0 }
      ]},
      {c: 40,funs: [
      { n: "serra", v: 13, p: 1, h: 0 },
      { n: "serra", v: 13, p: 0, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 11, p: 0, h: 0 },
      { n: "serra", v: 11, p: 0, h: 0 },
      { n: "serra", v: 13, p: 1, h: 0 }
      ]},
      {c: 40,funs: [
      { n: "serra", v: 13, p: 0, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 13, p: 0, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 13, p: 0, h: 0 }
      ]},
      {c: 45,funs: [
      {n:"lança",p:1}
      ]},
      {c: 45,funs: [
      {n:"lança",p:0}
      ]},
      {c: 60,funs: [
      {n:"lança",p:1},
      { n: "serra", v: 13, p: 0, h: 0 },
      {n:"lança",p:0},
      { n: "serra", v: 11, p: 1, h: 0 },
      { n: "serra", v: 11, p: 0, h: 0 },
      {n:"lança",p:1}
      ]},
      {c: 60,funs: [
      {n:"lança",p:0},
      { n: "serra", v: 11, p: 1, h: 0 },
      {n:"lança",p:1},
      { n: "serra", v: 11, p: 0, h: 0 },
      { n: "serra", v: 11, p: 1, h: 0 },
      {n:"lança",p:0}
      ]}



  ]
//      {n:"serra",v:10,p:1,h:0},
//      {n:"lança",p:1},


function spawn() {
peso=[];
ipeso=0;
while(ipeso<rules.length){
 peso[ipeso]=rules[ipeso].c;
  ipeso++;
}
pesoo();


  ik = Math.floor(Math.random()*(rules.length));

  armadilha();
}

function pesoo(){
  
  if(nV>=2){
    nP=60
  }
  else{
    nP=20*(nV+1);
  }
  
apeso = Math.floor(Math.random()*nP);
peso =peso.filter(x=>x>apeso);

if(peso.length != 0){
  peso=peso[(Math.floor(Math.random()*peso.length))]
  return peso;
}
else{
 return pesoo();
}
}


function armadilha() {

  

    if (go > (rules[ik].funs.length-1)||rules[ik].c!=peso) {
      go = 0;
      spawn();
    }
    else {

      if (rules[ik].funs[go].n == "serra") {
        spawSerra(rules[ik].funs[go].p, rules[ik].funs[go].v, rules[ik].funs[go].h)
      }
      if (rules[ik].funs[go].n == "lança") {
        SpawnLan(rules[ik].funs[go].p)
      }
      go++;
    }
  

}