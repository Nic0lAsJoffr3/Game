function HAB_vida(){
  if(habilidade>0 && mvida<6){
  mvida++;
  avida++;
  pause=false;
 habilidade--;
}}
function HAB_speed(){
  if(habilidade>0 && hspeed <= 3){
  hspeed++;
  pause=false;
 habilidade--;
}}