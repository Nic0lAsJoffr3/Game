
  spawn();
    setInterval(function update() {if(pause==false){
    lan();
    
  if(habilidade>0){
    pause=true;
  }
    if(avida>=0){
    //vida
    
    vidaX[0]=74*mvida;
    vidaX[1]=74*avida;
    if(avida>mvida){
      avida=mvida;
    }
    
    if(vv>0){
    vv-=1;
    }
    //--
    ponto2+=0.1;
    pnv=((ponto2)*88.5)/mmU;
    if((ponto2) >= mmU && avida >0){
      ponto2=0;
      
      if(nv<4){
      nv+=1;
      
      }
      nV+=1;
      habilidade+=1;
      mmU+=5*nV;
      
      
    }
    
    
    
if(ponto%200 > 100){
  modo=2;
}
else{
  modo=1;
}}


      if (gameover == true &&vv<=0) {
        if(avida>0){
          avida-=0.25;
          vv=7  
          gameover=false;
        }
        if(avida<=0){
          
        
          document.querySelector(".go").style=`
          transform:translate(0px,325px);
          `
        document.querySelector(".go").innerHTML = `<br>
        Fim de jogo<br>
        <a style="color:white;" href='index.html'>Jogar novamente</a>
        
        
        `} 
    
      }
      else{
     
        if(ix>0){
          ix-=hspeed*5;
          x-=hspeed*5;
        }
        else if(ix<0){
          ix+=hspeed*5;
          x+=hspeed*5;
        }
      
      if(arm==1){
        if(lanM == 1 && uu==false){
          
          if (lanOb < 11) {colorB[1]="red";
              lanOb += 0.1;
            }
            else {
              colorB[1]=color[0]
          if(lanXY[0][1] >125){
            lanXY[0][1]-= 7;
          }
          
           if(lanXY[1][1] > 125){
            lanXY[1][1]-= 7;
          }
           if(lanXY[2][1] > 125 ){
            lanXY[2][1]-= 7;
          }
          if(lanXY[5][1] > 125 ){
            lanXY[5][1]-= 7;
          }
          
           if(lanXY[4][1] > 125 ){
            lanXY[4][1]-= 7;
          }
           if(lanXY[3][1] > 125 ){
            lanXY[3][1]-= 7;
          }
        }
        }
        else if(lanM == 2 && uu==false){
          if (lanOu < 11) {
            colorB[0]="red";
            lanOu += 0.1;
          }
          else {
            colorB[0]=color[0]
          if(lanXY[0][1] < -25 ){
            lanXY[0][1]+= 7;
          }
          
           if(lanXY[1][1] < -25 ){
            lanXY[1][1]+= 7;
          }
           if(lanXY[2][1] < -25 ){
            lanXY[2][1]+= 7;
          }
          if(lanXY[5][1] < -25 ){
            lanXY[5][1]+= 7;
          }
          
           if(lanXY[4][1] < -25 ){
            lanXY[4][1]+= 7;
          }
           if(lanXY[3][1] < -25 ){
            lanXY[3][1]+= 7;
          }
          }
          
          
        }
        
        if(i>0){
          i-=0.2
        }
        else{
          uu=true;
          if(lanM==1){
        
            lanXY[0][1]+=2;
            lanXY[1][1]+=2;
            lanXY[2][1]+=2;
            lanXY[3][1]+=2;
            lanXY[4][1]+=2;
            lanXY[5][1]+=2;
                  lanOb-=0.05;
            
            if(lanXY[5][1] > 500){
              lanOb=5;
              armadilha();
            }
          }
          else if(lanM==2){
            
            lanXY[0][1]-=2;
            lanXY[1][1]-=2;
            lanXY[2][1]-=2;
            lanXY[3][1]-=2;
            lanXY[4][1]-=2;
            lanXY[5][1]-=2;
            lanOu-=0.05;
            if(lanXY[5][1] < -200){
             lanOu=5;
              armadilha();
            }
          }
        }}
        if(y==0 && lanM==2 && lanOu>=11){
      
            gameover=true;
          }
        
        else if(y==310 && lanM==1 && lanOb>=11){
          
              gameover = true;
            }
        
        
        
        if (y > 0 && up == false && jump0 == true) {
          y -= speedjump;

        }
        if (y < 310 && up == true && jump0 == true) {
          y += speedjump;



        }
        else if (y < 5 && y > -5) {
          up = true;
          jump0 = false;
          y = 0;
        }

        else if (y < 315 && y > 305) {
          up = false;
          jump0 = false;
          y = 310;
        }
        ponto += 0.05;

       
  if(arm==2){
        if (serraX + 80 > x - 20 && serraX < x + 100) {
          if (serraY < 0 && y == 0) {

            gameover = true;
          }
          if (serraY > 0 && y == 310) {

            gameover = true;
          }
        }
        
        if (sSerra == true) {
          if (serraX > X_max) {
            serraX -= serraSpeed;
          }
          if (serraX <= X_max) {
            armadilha();
          }
        }
      }
      }}
    }, 10)
