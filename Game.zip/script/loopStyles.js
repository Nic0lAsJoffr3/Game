setInterval(function updateStyle() {
  document.querySelector(".lbar1").style = `
      width: ${vidaX[0]}px;
      height: 25px;
      background-color: transparent;
      border: 1px solid ${color[0]};
      position: absolute;
      
      transform:translate(-25px,90px);
      `
  document.querySelector(".lbar2").style = `
            width: ${vidaX[1]}px;
            height: 25px;
            background-color: ${color[0]};
            border: 1px solid ${color[0]};
            position: absolute;
            
            transform:translate(-25px,90px);
            `
  if (mvida >= 6) {
    document.querySelector(".h1").style = `
        opacity:0;
        `;
  }
  if (arm == 2) {
    if (modo == 1) {
      colorB = ["white", "white"]
      color = ["white", "black"]
      document.getElementById("img-serra").src = "IMG/serra.png";
      srclan = "IMG/lan.png"
    }
    else if (modo == 2) {
      colorB = ["black", "black"]
      color = ["black", "white"]
      document.getElementById("img-serra").src = "IMG/serraBlack.png";
      srclan = "IMG/lanBlack.png";
    }
  }


  document.getElementById("PONTO").innerHTML = "Pontos: " + Math.floor(ponto) + " Nível: " + nV;

  document.querySelector(".jump").style = `
      width: 125px;
      font-size: 25px;
      height: 125px;
      border-radius:50%;
      border:1px solid ${color[0]};
background-color: transparent;
position:absolute;
color:${color[0]};
     transform: translate(187.5px,350px);
     `
  document.querySelector(".left").style = `
      width: 60px;
      font-size: 35px;
      height: 60px;
      border-radius:50%;
      border:1px solid ${color[0]};
background-color: transparent;
color:${color[0]};
     transform: translate(0px,350px);
     position:absolute;
     `
  document.querySelector(".right").style = `
      width: 60px;
      font-size: 35px;
      height: 60px;
      border-radius:50%;
      border:1px solid ${color[0]};
background-color: transparent;
color:${color[0]};
     transform: translate(425px,350px);
     position:absolute;
     `
  document.getElementById("Bni").style = `
      position:absolute;
      height:10px;
      width:88.5%;
      border:1px solid   ${color[0]};
      transform:translate(15px,275px);
      
      `;
  if (avida > 0) {
    document.getElementById("ni").style = `
      position:absolute;
      height:10px;
      width:${pnv}%;
      border:1px solid   ${color[0]};
      transform:translate(15px,275px);
      background-color:  ${color[0]};
      
      `;
  }
  serra.style = `
   
      transform: translate(${serraX}%,${serraY}%) ;`

   if(pause==true){
  
  player.style = "display:none;"
  document.querySelector(".game").style = "display:none;";
}
else{
  player.style = `
   
      background-color:   ${color[0]};
      height:50px;
      width: 50px;
      border-radius:50%;
      z-index:9999;
      transform: translate(${x}%,${y}%);
   `;
  document.querySelector(".game").style = `
  
  
      height:200px;
      width:95%;
   border-top: ${colorB[0]} 5px solid; 
   border-bottom: ${colorB[1]} 5px solid; 
  
background-color: transparent;
     
      z-index: 99;
  `}
  document.querySelector("body").style = `
  
  background-color:${color[1]};
  color:${color[0]};
  `
  document.getElementById("PONTO").style = `
  
      color: ${color[0]};
      position: absolute;
      transform: translateY(1150%);
  
  `

  document.querySelector("#hab").style = `
        transform:translate(-9px,-9px);
        background-color:black;
        text-align:center;
        
        width:100%;
        opacity:1;
        height:100%;
        border:none;
        color:white;
        `

  document.querySelector("#life").style = `
        transform:translate(40px,155px);
      
        `

  if (habilidade <= 0) {

    document.querySelector("#hab").style = `
                 display:none;
                 `;
  }
}, 1);




function lan() {


  document.getElementById("lan").innerHTML = "";
  document.getElementById("lan").innerHTML += `<img id="img-lan" src="${srclan}" class="img-lan" style="transform:translate(${lanXY[0][0]}%,${lanXY[0][1]}%) rotate(${lanXY[0][2]}deg);">`;
  document.getElementById("lan").innerHTML += `<img id="img-lan" src="${srclan}" class="img-lan" style="transform:translate(${lanXY[1][0]}%,${lanXY[1][1]}%) rotate(${lanXY[1][2]}deg);">`;
  document.getElementById("lan").innerHTML += `<img id="img-lan" src="${srclan}" class="img-lan" style="transform:translate(${lanXY[2][0]}%,${lanXY[2][1]}%) rotate(${lanXY[2][2]}deg);">`;
  document.getElementById("lan").innerHTML += `<img id="img-lan" src="${srclan}" class="img-lan" style="transform:translate(${lanXY[3][0]}%,${lanXY[3][1]}%) rotate(${lanXY[3][2]}deg);">`;
  document.getElementById("lan").innerHTML += `<img id="img-lan" src="${srclan}" class="img-lan" style="transform:translate(${lanXY[4][0]}%,${lanXY[4][1]}%) rotate(${lanXY[4][2]}deg);">`;
  document.getElementById("lan").innerHTML += `<img id="img-lan" src="${srclan}" class="img-lan" style="transform:translate(${lanXY[5][0]}%,${lanXY[5][1]}%) rotate(${lanXY[5][2]}deg);">`;


}