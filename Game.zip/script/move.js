function jump() { if (pause==false&&y == 310 || y == 0) { jump0 = true; } }
    
    
    
function right(){
  if(pause==false&& x < 700){
      x+=hspeed*40;
  }
}



  function left() {
    if (pause==false&&x > 10) {
      x-=hspeed*40;
    }
}