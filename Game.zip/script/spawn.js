//lança{
         function SpawnLan(spu) {
           i = 39-nv;
           arm = 1;
           
           uu=false;
           if (spu == 0) {
             
             lanXY[0][2] = 180;
             lanXY[1][2] = 180;
             lanXY[2][2] = 180;
             lanXY[3][2] = 180;
             lanXY[4][2] = 180;
             lanXY[5][2] = 180;
         
         
             lanXY[0][1] = -200;
             lanXY[1][1] = -200;
             lanXY[2][1] = -200;
             lanXY[3][1] = -200;
             lanXY[4][1] = -200;
             lanXY[5][1] = -200;
             lanM = 2;
         
           }
          else if (spu == 1) {
           
             lanXY[0][2] = 0;
             lanXY[1][2] = 0;
             lanXY[2][2] = 0;
             lanXY[3][2] = 0;
             lanXY[4][2] = 0;
             lanXY[5][2] = 0;
         
         
             lanXY[0][1] = 500;
             lanXY[1][1] = 500;
             lanXY[2][1] = 500;
             lanXY[3][1] = 500;
             lanXY[4][1] = 500;
             lanXY[5][1] = 500;
             lanM = 1;
        
           }
           lan();
           
         }
         //}
         
         //serra{
              
    function spawSerra(positionnn, velocity, horizont) {
      arm=2;
    
      positions = [-50, 350]

      serraY = positions[positionnn]
      serraSpeed = velocity+nv;
      serraX = 900;
      X_max = -300;
      sSerra = true;


    }
    //}