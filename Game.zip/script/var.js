habilidade=0;
avida=1;
mvida=1;
hspeed=1;
pause=false;
vidaX=[50,0]
        vv=0;
        
    color = [];
    modo = 2;
    gameover = false
    x = 300;
    serraX = 0;
    sSerra = false;
    up = false;
    X_max = 0;
    serraY = 0;
    lanM =0;
    serraSpeed = 0;
    derlayjump = 0;
    speedjump = 12;
    jump0 = false;
    ponto = 0;
    ponto2=0;
    y = 0;
    uu=false;
    nv=0;
    nV=0;
    pnv=0;
    imNivel=0;
    ix=0;
    mmU=100;
    i=0;
    arm=0;
    lanOu=5;
    lanOb=5;
    colorB="";
    lanXY=[
      
      [-20,200,0],
      [60,200,0],
      [140,200,0],
      [220,200,0],
      [300,200,0],
      [380,200,0]
      
      ]
      
    srclan="IMG/lan.png"
      
    player = document.getElementById("player");
    
    serra = document.getElementById("serra");
    
    imgserra = document.getElementById("img-serra");